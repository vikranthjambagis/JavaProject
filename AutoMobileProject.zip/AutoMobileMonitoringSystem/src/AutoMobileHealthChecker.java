
public class AutoMobileHealthChecker {
	
	public AutoMobileHealthChecker(AutomobileParametersStatusImpl params_status) {
		super();
		this.params_status = params_status;
	}
	AutomobileParametersStatus params_status;
	
	
	String oilStatus=params_status.getEngineOilStatus();
	String coolantStatus=params_status.getCoolantStatus();
	String fuelStatus=params_status.getFuelStatus();
	String pressureStatus=params_status.getTyprePressureStatus();
	String batteryStatus=params_status.getBatteryStatus();
	
	int  greenCount;
	int amberCount;
	int redCount;
	String overallStatus;

	
	
	
	public void runStatusCount()
	{
		switch (oilStatus) {
		case "green":
			greenCount++;
			
		case "amber":
			amberCount++;
			
		case "red":
			redCount++;
		}
		
		
		switch (coolantStatus) {
		case "green":
			greenCount++;
			
		case "amber":
			amberCount++;
			
		case "red":
			redCount++;
		}
		
		switch (fuelStatus) {
		case "green":
			greenCount++;
			
		case "amber":
			amberCount++;
			
		case "red":
			redCount++;
		}
		
		switch (pressureStatus) {
		case "green":
			greenCount++;
			
		case "amber":
			amberCount++;
			
		case "red":
			redCount++;
		}
	
	
	switch (batteryStatus) {
	case "green":
		greenCount++;
		
	case "amber":
		amberCount++;
		
	case "red":
		redCount++;
	default:
		break;
	}
		
	}
		
	
	public String getHealthStatus()
	{
		
		runStatusCount();
		
		if(redCount>=1 || amberCount>3)
		overallStatus="red";
		else if(greenCount==5 ||amberCount==2 )
		overallStatus="green";
		else if(amberCount>=2 && greenCount<5)
		overallStatus="green";
		
		
		
		return overallStatus;
		
		
	}
	

}
