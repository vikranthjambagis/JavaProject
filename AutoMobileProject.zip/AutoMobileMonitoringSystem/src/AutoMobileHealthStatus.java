public class AutoMobileHealthStatus {

	
	public AutoMobileHealthStatus(AutoMobileHealthChecker healthChecker) {
		super();
		this.healthChecker = healthChecker;
	}

	AutoMobileHealthChecker healthChecker;
	String healthStatus;
	
	
	public String getHealthStatus()
	{
		healthStatus=healthChecker.getHealthStatus();
		
		return healthStatus;
		
	}
	
	
	
}
