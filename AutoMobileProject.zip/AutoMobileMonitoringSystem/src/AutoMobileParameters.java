
public class AutoMobileParameters {
	
	int oil_level;
	int coolant_level;
	int fuel_level;
	int tyre_pressure;
	int battery_level;
	
	public int getOil_level() {
		return oil_level;
	}
	public int getCoolant_level() {
		return coolant_level;
	}
	public int getFuel_level() {
		return fuel_level;
	}
	public int getTyre_pressure() {
		return tyre_pressure;
	}
	public int getBattery_level() {
		return battery_level;
	}
	

}
