
public interface AutomobileParametersStatus {

	public String getEngineOilStatus();
	public String getCoolantStatus();
	public String getFuelStatus();
	public String getTyprePressureStatus();
	public String getBatteryStatus();
	
}
