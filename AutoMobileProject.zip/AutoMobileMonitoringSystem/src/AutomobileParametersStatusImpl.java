
public class AutomobileParametersStatusImpl implements AutomobileParametersStatus{

	
	public AutomobileParametersStatusImpl(AutoMobileParameters params) {
		super();
		this.params = params;
	}

	AutoMobileParameters params;
	
	
	@Override
	public String getEngineOilStatus() {
		
		
		if(params.getOil_level()<10)
		return "red";
		else if(params.getOil_level()>50)
		return "green";
		else
		return "amber";
		
	}

	@Override
	public String getCoolantStatus() {
		if(params.getCoolant_level()<30)
			return "red";
			else if(params.getCoolant_level()>60)
			return "green";
			else
			return "amber";
	}

	@Override
	public String getFuelStatus() {
		if(params.getFuel_level()<2)
			return "red";
			else if(params.getFuel_level()>5)
			return "green";
			else
			return "amber";
	}

	@Override
	public String getTyprePressureStatus() {
		if(params.getTyre_pressure()<30)
			return "red";
			else if(params.getTyre_pressure()>35)
			return "green";
			else
			return "amber";
	}

	@Override
	public String getBatteryStatus() {
		if(params.getBattery_level()<20)
			return "red";
			else if(params.getBattery_level()>70)
			return "green";
			else
			return "amber";
	}

}
